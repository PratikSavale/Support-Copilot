# Support-Copilot Pitch Notes

## 60-second opener

Support-Copilot is an AI-powered L2 support assistant. The core idea is simple: every ticket should get immediate attention, even when the L2 team is busy or offline.

Today, L2 engineers spend too much time on repetitive support work: reading the same symptoms, searching the same docs, asking the same follow-up questions, and creating Jira tickets manually. Support-Copilot changes that flow. It answers known issues from trusted documentation, asks clarifying questions when details are missing, and escalates unknown issues into Jira with structured context.

The product is not trying to replace L2. It reduces the repeatable workload so L2 can focus on complex incidents, production risk, customer escalations, and root-cause fixes.

## Strong pitch line

Support-Copilot gives every ticket instant 24/7 attention and gives every L2 engineer more time for the work only humans can do.

## Real-life benchmark numbers to mention

- Gartner predicts agentic AI will autonomously resolve 80% of common customer service issues by 2029 and reduce operational costs by 30%.
- McKinsey estimates generative AI can create 30-45% productivity value in customer-care functions.
- Freshworks benchmark data shows GenAI features can reduce resolution time by up to 38%, and knowledge bases can halve resolution times.
- Freshworks 2025 benchmark reporting shows real-time conversation resolution moving from 41 minutes without AI assistance to 2 minutes with AI copilots in high-performing cohorts.
- Salesforce State of Service 2024 reports that 77% of agents say workload increased, 65% say cases became more complex, and agents spend only 39% of time actually servicing customers.

## Conservative impact model for judges

Use a 100-ticket/day L2 team:

- 100 tickets get instant triage instead of waiting in queue.
- 45-55 tickets can be resolved directly from documentation/runbooks if the issue is known and confidence is high.
- 20-25 tickets can be clarified, guided, or partially solved before any human picks them up.
- 20-30 tickets still escalate, but with complete Jira fields: summary, severity, module, environment, error messages, reproduction steps, troubleshooting already tried, and source references.

Monthly capacity example:

- 100 tickets/day for 22 business days = 2,200 tickets/month.
- 45% direct AI resolution = 990 fewer manual tickets/month.
- If each manual L2 ticket takes 30 minutes, that is 495 hours/month saved.
- At 160 hours/month per person, that unlocks about 3 FTE of L2 capacity.
- At $35/hour fully loaded cost, that is about $17K/month or $208K/year in capacity value.

Position this as a planning estimate, not a guaranteed production number. The real pilot will validate it against the actual ticket mix and knowledge-base coverage.

## Slide-by-slide talk track

### 1. Title

Open with the product name and the promise: instant L2 support assistance with grounded answers and smart escalation.

### 2. Problem

Explain that the team is not failing because of lack of effort. They are fighting scale: more tickets, more complex issues, and too much administrative work.

### 3. Why now

Use the market proof. AI support is not a future fantasy anymore. Gartner, McKinsey, Freshworks, and Salesforce all point to measurable gains in resolution, productivity, and cost.

### 4. Product

Describe the three product surfaces: user chat, knowledge brain, and admin control. Make it clear that the repo already has these pieces: FastAPI backend, React frontend, ChromaDB RAG, PostgreSQL, confidence service, Jira integration, and analytics.

### 5. Workflow

Walk through the decision flow: ask, clarify, retrieve, decide, handoff. Emphasize the safety: the assistant answers with sources, asks questions when unsure, and escalates instead of hallucinating.

### 6. Before vs after

Show the daily routine transformation. Before: queue, search, repeat, manual Jira. After: instant attention, source-backed answers, guided clarification, structured escalation.

### 7. Time reduction

Use Freshworks benchmark numbers to show why this is credible. The exact numbers are external benchmarks, and our pilot will measure our own baseline.

### 8. Ticket-volume model

This is the judge-friendly model. Repeat the 100-ticket scenario and show that even a conservative 45% direct resolution rate changes L2 capacity dramatically.

### 9. ROI

Translate saved tickets into hours and money. Keep it grounded: the strongest ROI is not only cost saving, but faster recovery and fewer repeated escalations.

### 10. More than a chatbot

This is the differentiation slide. Stress RAG, confidence routing, Jira-native handoff, admin observability, and knowledge gap feedback.

### 11. Demo storyline

Explain how judges will see value in three minutes: admin loads knowledge, user asks a known issue, unknown issue escalates into Jira, admin dashboard updates.

### 12. Pilot and sources

Close with a practical ask: run a two-week pilot, connect top docs and top issue types, and measure first response, direct resolution, manual L2 volume reduction, and escalation quality.

## Final closing

Support-Copilot is a winning idea because it is not just a chatbot demo. It is an operational support system. It reduces repeated L2 work, gives users 24/7 immediate attention, creates cleaner tickets, and turns every unresolved issue into a signal for improving the knowledge base.

## Source links

- Gartner: https://www.gartner.com/en/newsroom/press-releases/2025-03-05-gartner-predicts-agentic-ai-will-autonomously-resolve-80-percent-of-common-customer-service-issues-without-human-intervention-by-20290
- McKinsey: https://www.mckinsey.com/capabilities/tech-and-ai/our-insights/The-economic-potential-of-generative-AI-The-next-productivity-frontier
- Freshworks 2024 benchmark article: https://www.freshworks.com/theworks/customer-experience/freshworks-customer-service-benchmark-report-2024/
- Freshworks 2025 AI benchmark article: https://www.freshworks.com/theworks/customer-experience/freshworks-20205-cx-benchmark-thriving-with-ai/
- Salesforce State of Service 2024 article: https://www.salesforce.com/news/stories/customer-service-statistics-2024/
