from __future__ import annotations

import html
import zipfile
from datetime import datetime, timezone
from pathlib import Path


OUT_DIR = Path(__file__).resolve().parent
PPTX_PATH = OUT_DIR / "Support-Copilot-Pitch-Deck.pptx"

EMU_PER_INCH = 914400
SLIDE_W = int(13.333333 * EMU_PER_INCH)
SLIDE_H = int(7.5 * EMU_PER_INCH)

COLORS = {
    "navy": "08111F",
    "midnight": "0C1728",
    "ink": "132238",
    "blue": "2563EB",
    "cyan": "06B6D4",
    "green": "16A34A",
    "lime": "84CC16",
    "amber": "F59E0B",
    "red": "DC2626",
    "white": "FFFFFF",
    "offwhite": "F8FAFC",
    "muted": "CBD5E1",
    "slate": "64748B",
    "panel": "111827",
    "panel2": "172033",
    "line": "334155",
}


def emu(value: float) -> int:
    return int(value * EMU_PER_INCH)


def xml_escape(value: str) -> str:
    return html.escape(value, quote=True)


def alpha_tag(percent: int) -> str:
    return f'<a:alpha val="{int(percent * 1000)}"/>'


class SlideBuilder:
    def __init__(self, bg: str = COLORS["navy"]) -> None:
        self.bg = bg
        self.shapes: list[str] = []
        self._shape_id = 2

    def next_id(self) -> int:
        shape_id = self._shape_id
        self._shape_id += 1
        return shape_id

    def text(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        text: str,
        size: int = 24,
        color: str = COLORS["white"],
        bold: bool = False,
        align: str = "l",
        valign: str = "t",
        font: str = "Aptos",
        line_spacing: int | None = None,
        transparency: int | None = None,
    ) -> None:
        sid = self.next_id()
        rpr = f'lang="en-US" sz="{size * 100}"'
        if bold:
            rpr += ' b="1"'
        fill = f'<a:solidFill><a:srgbClr val="{color}">'
        if transparency is not None:
            fill += alpha_tag(100 - transparency)
        fill += "</a:srgbClr></a:solidFill>"
        ppr = f'<a:pPr algn="{align}"/>'
        if line_spacing is not None:
            ppr = f'<a:pPr algn="{align}"><a:lnSpc><a:spcPct val="{line_spacing}"/></a:lnSpc></a:pPr>'
        self.shapes.append(
            f"""
            <p:sp>
              <p:nvSpPr><p:cNvPr id="{sid}" name="Text {sid}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
              <p:spPr>
                <a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>
                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                <a:noFill/><a:ln><a:noFill/></a:ln>
              </p:spPr>
              <p:txBody>
                <a:bodyPr wrap="square" anchor="{valign}"><a:spAutoFit/></a:bodyPr>
                <a:lstStyle/>
                <a:p>{ppr}<a:r><a:rPr {rpr}>{fill}<a:latin typeface="{font}"/></a:rPr><a:t>{xml_escape(text)}</a:t></a:r><a:endParaRPr {rpr}/></a:p>
              </p:txBody>
            </p:sp>
            """
        )

    def multiline_text(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        lines: list[str],
        size: int = 18,
        color: str = COLORS["muted"],
        bold_first: bool = False,
        font: str = "Aptos",
        line_spacing: int = 100000,
    ) -> None:
        sid = self.next_id()
        paragraphs = []
        for idx, line in enumerate(lines):
            is_bold = bold_first and idx == 0
            rpr = f'lang="en-US" sz="{size * 100}"'
            if is_bold:
                rpr += ' b="1"'
            fill = f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
            paragraphs.append(
                f'<a:p><a:pPr><a:lnSpc><a:spcPct val="{line_spacing}"/></a:lnSpc></a:pPr>'
                f'<a:r><a:rPr {rpr}>{fill}<a:latin typeface="{font}"/></a:rPr><a:t>{xml_escape(line)}</a:t></a:r>'
                f'<a:endParaRPr {rpr}/></a:p>'
            )
        self.shapes.append(
            f"""
            <p:sp>
              <p:nvSpPr><p:cNvPr id="{sid}" name="Text {sid}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
              <p:spPr>
                <a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>
                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                <a:noFill/><a:ln><a:noFill/></a:ln>
              </p:spPr>
              <p:txBody>
                <a:bodyPr wrap="square" anchor="t"><a:spAutoFit/></a:bodyPr>
                <a:lstStyle/>
                {''.join(paragraphs)}
              </p:txBody>
            </p:sp>
            """
        )

    def bullet_list(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        bullets: list[str],
        size: int = 18,
        color: str = COLORS["offwhite"],
        bullet_color: str | None = None,
        line_spacing: int = 106000,
    ) -> None:
        sid = self.next_id()
        bullet_color = bullet_color or color
        paragraphs = []
        for bullet in bullets:
            rpr = f'lang="en-US" sz="{size * 100}"'
            fill = f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
            bu_fill = f'<a:buClr><a:srgbClr val="{bullet_color}"/></a:buClr>'
            paragraphs.append(
                '<a:p>'
                f'<a:pPr marL="228600" indent="-171450"><a:lnSpc><a:spcPct val="{line_spacing}"/></a:lnSpc>{bu_fill}<a:buFont typeface="Arial"/><a:buChar char="•"/></a:pPr>'
                f'<a:r><a:rPr {rpr}>{fill}<a:latin typeface="Aptos"/></a:rPr><a:t>{xml_escape(bullet)}</a:t></a:r>'
                f'<a:endParaRPr {rpr}/>'
                '</a:p>'
            )
        self.shapes.append(
            f"""
            <p:sp>
              <p:nvSpPr><p:cNvPr id="{sid}" name="Bullets {sid}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
              <p:spPr>
                <a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>
                <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                <a:noFill/><a:ln><a:noFill/></a:ln>
              </p:spPr>
              <p:txBody>
                <a:bodyPr wrap="square" anchor="t"><a:spAutoFit/></a:bodyPr>
                <a:lstStyle/>
                {''.join(paragraphs)}
              </p:txBody>
            </p:sp>
            """
        )

    def rect(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        fill: str,
        line: str | None = None,
        transparency: int = 0,
        radius: str = "roundRect",
        line_width: int = 12700,
    ) -> None:
        sid = self.next_id()
        line_xml = '<a:ln><a:noFill/></a:ln>'
        if line:
            line_xml = f'<a:ln w="{line_width}"><a:solidFill><a:srgbClr val="{line}"/></a:solidFill></a:ln>'
        fill_xml = f'<a:solidFill><a:srgbClr val="{fill}">'
        if transparency:
            fill_xml += alpha_tag(100 - transparency)
        fill_xml += "</a:srgbClr></a:solidFill>"
        self.shapes.append(
            f"""
            <p:sp>
              <p:nvSpPr><p:cNvPr id="{sid}" name="Rect {sid}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
              <p:spPr>
                <a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>
                <a:prstGeom prst="{radius}"><a:avLst/></a:prstGeom>
                {fill_xml}
                {line_xml}
              </p:spPr>
            </p:sp>
            """
        )

    def line(self, x1: float, y1: float, x2: float, y2: float, color: str = COLORS["line"], width: int = 19050) -> None:
        sid = self.next_id()
        x = min(x1, x2)
        y = min(y1, y2)
        w = abs(x2 - x1)
        h = abs(y2 - y1)
        flip_h = ' flipH="1"' if x2 < x1 else ""
        flip_v = ' flipV="1"' if y2 < y1 else ""
        self.shapes.append(
            f"""
            <p:cxnSp>
              <p:nvCxnSpPr><p:cNvPr id="{sid}" name="Line {sid}"/><p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr>
              <p:spPr>
                <a:xfrm{flip_h}{flip_v}><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>
                <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
                <a:ln w="{width}"><a:solidFill><a:srgbClr val="{color}"/></a:solidFill></a:ln>
              </p:spPr>
            </p:cxnSp>
            """
        )

    def title(self, title: str, subtitle: str | None = None) -> None:
        self.text(0.55, 0.35, 8.5, 0.45, "Support-Copilot", size=13, color=COLORS["cyan"], bold=True)
        self.text(0.55, 0.78, 9.9, 0.65, title, size=31, color=COLORS["white"], bold=True, font="Aptos Display")
        if subtitle:
            self.text(0.58, 1.38, 10.4, 0.45, subtitle, size=14, color=COLORS["muted"])

    def metric_card(
        self,
        x: float,
        y: float,
        w: float,
        h: float,
        value: str,
        label: str,
        fill: str = COLORS["panel2"],
        accent: str = COLORS["cyan"],
        source: str | None = None,
    ) -> None:
        self.rect(x, y, w, h, fill=fill, line=COLORS["line"])
        self.rect(x, y, 0.09, h, fill=accent, radius="rect")
        self.text(x + 0.25, y + 0.25, w - 0.45, 0.45, value, size=27, color=COLORS["white"], bold=True, font="Aptos Display")
        self.text(x + 0.25, y + 0.78, w - 0.45, 0.55, label, size=12, color=COLORS["muted"])
        if source:
            self.text(x + 0.25, y + h - 0.33, w - 0.45, 0.2, source, size=7, color=COLORS["slate"])

    def footer(self, text: str = "Benchmark sources and assumptions shown in final slide.") -> None:
        self.line(0.55, 7.03, 12.78, 7.03, COLORS["line"], width=9000)
        self.text(0.58, 7.08, 8.0, 0.22, text, size=7, color=COLORS["slate"])

    def xml(self) -> str:
        bg_xml = f"""
        <p:bg>
          <p:bgPr>
            <a:solidFill><a:srgbClr val="{self.bg}"/></a:solidFill>
            <a:effectLst/>
          </p:bgPr>
        </p:bg>
        """
        return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
               xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
               xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
          <p:cSld>
            {bg_xml}
            <p:spTree>
              <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
              <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{SLIDE_W}" cy="{SLIDE_H}"/><a:chOff x="0" y="0"/><a:chExt cx="{SLIDE_W}" cy="{SLIDE_H}"/></a:xfrm></p:grpSpPr>
              {''.join(self.shapes)}
            </p:spTree>
          </p:cSld>
          <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
        </p:sld>
        """


def add_bar(slide: SlideBuilder, x: float, y: float, w: float, label: str, value: str, pct: float, color: str) -> None:
    slide.text(x, y, 3.4, 0.25, label, size=12, color=COLORS["muted"], bold=True)
    slide.rect(x, y + 0.36, w, 0.24, fill=COLORS["ink"], radius="roundRect")
    slide.rect(x, y + 0.36, w * pct, 0.24, fill=color, radius="roundRect")
    slide.text(x + w + 0.2, y + 0.29, 1.2, 0.28, value, size=14, color=COLORS["white"], bold=True)


def build_slides() -> list[SlideBuilder]:
    slides: list[SlideBuilder] = []

    s = SlideBuilder()
    s.rect(0, 0, 13.33, 7.5, fill=COLORS["navy"], radius="rect")
    s.rect(8.6, -0.4, 5.1, 8.4, fill="0E7490", transparency=18, radius="rect")
    s.rect(9.25, 0.75, 3.35, 4.8, fill=COLORS["panel"], transparency=5, line=COLORS["cyan"])
    s.text(9.55, 1.02, 2.8, 0.25, "LIVE AI TRIAGE", size=10, color=COLORS["cyan"], bold=True, align="c")
    s.rect(9.65, 1.55, 2.1, 0.36, fill=COLORS["blue"])
    s.rect(9.65, 2.1, 2.55, 0.36, fill=COLORS["ink"], line=COLORS["line"])
    s.rect(9.65, 2.65, 1.85, 0.36, fill=COLORS["green"])
    s.text(9.72, 3.35, 2.35, 0.28, "KB match: 0.82", size=12, color=COLORS["white"], bold=True)
    s.text(9.72, 3.78, 2.35, 0.28, "Action: resolve", size=12, color=COLORS["green"], bold=True)
    s.text(0.65, 0.5, 4.0, 0.35, "Stakeholder pitch deck", size=13, color=COLORS["cyan"], bold=True)
    s.text(0.65, 1.25, 7.8, 1.0, "Support-Copilot", size=52, color=COLORS["white"], bold=True, font="Aptos Display")
    s.text(0.72, 2.26, 7.4, 0.7, "AI-powered L2 support assistant that resolves known issues instantly and escalates unknown issues with full Jira-ready context.", size=20, color=COLORS["muted"], line_spacing=94000)
    s.rect(0.72, 3.55, 2.3, 0.75, fill=COLORS["blue"])
    s.text(0.92, 3.76, 1.9, 0.25, "Instant attention", size=13, color=COLORS["white"], bold=True, align="c")
    s.rect(3.25, 3.55, 2.35, 0.75, fill=COLORS["green"])
    s.text(3.45, 3.76, 1.95, 0.25, "RAG + sources", size=13, color=COLORS["white"], bold=True, align="c")
    s.rect(5.85, 3.55, 2.15, 0.75, fill=COLORS["amber"])
    s.text(6.05, 3.76, 1.75, 0.25, "Jira handoff", size=13, color=COLORS["white"], bold=True, align="c")
    s.text(0.75, 6.65, 8.5, 0.25, "Goal: reduce L2 workload while improving customer response time, coverage, and knowledge reuse.", size=12, color=COLORS["muted"])
    slides.append(s)

    s = SlideBuilder()
    s.title("The L2 support problem is not effort. It is scale.", "Ticket volume rises, cases get more complex, and high-value engineers spend too much time repeating known fixes.")
    s.metric_card(0.75, 2.0, 3.0, 1.45, "77%", "agents say workload increased over the past year", accent=COLORS["amber"], source="Salesforce State of Service 2024")
    s.metric_card(4.05, 2.0, 3.0, 1.45, "65%", "agents say cases are more complex than a year ago", accent=COLORS["red"], source="Salesforce State of Service 2024")
    s.metric_card(7.35, 2.0, 3.0, 1.45, "39%", "of agent time is spent actually servicing customers", accent=COLORS["cyan"], source="Salesforce State of Service 2024")
    s.metric_card(10.65, 2.0, 1.95, 1.45, "76%", "expect higher case volume", accent=COLORS["blue"], source="Salesforce")
    s.rect(0.75, 4.25, 11.85, 1.55, fill=COLORS["panel"], line=COLORS["line"])
    s.text(1.05, 4.52, 2.1, 0.3, "What breaks today", size=18, color=COLORS["white"], bold=True)
    s.bullet_list(3.2, 4.43, 8.85, 0.95, [
        "Known issues still wait in queue before anyone reads them.",
        "L2 agents repeatedly search docs, summarize chats, and create Jira tickets manually.",
        "Off-hours tickets lose time before the first useful action."
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["amber"], line_spacing=98000)
    s.footer()
    slides.append(s)

    s = SlideBuilder()
    s.title("Why this idea wins now", "The market is already moving from AI assistance to autonomous service resolution.")
    s.metric_card(0.78, 2.0, 3.6, 1.65, "80%", "of common customer service issues could be autonomously resolved by agentic AI by 2029", accent=COLORS["cyan"], source="Gartner, Mar 2025")
    s.metric_card(4.85, 2.0, 3.6, 1.65, "30%", "projected operational cost reduction from that shift", accent=COLORS["green"], source="Gartner, Mar 2025")
    s.metric_card(8.9, 2.0, 3.55, 1.65, "30-45%", "customer-care productivity value range from generative AI", accent=COLORS["blue"], source="McKinsey")
    s.rect(1.1, 4.5, 11.15, 1.1, fill=COLORS["panel2"], line=COLORS["line"])
    s.text(1.42, 4.78, 10.5, 0.4, "Our wedge: L2 support has exactly the data AI needs: docs, historic tickets, logs, and repeatable runbooks.", size=21, color=COLORS["white"], bold=True, align="c")
    s.text(1.42, 5.33, 10.5, 0.26, "Support-Copilot turns that knowledge into 24/7 triage, grounded answers, and cleaner escalation.", size=13, color=COLORS["muted"], align="c")
    s.footer()
    slides.append(s)

    s = SlideBuilder()
    s.title("The product", "An AI L2 assistant built around grounded resolution, confidence, and human-safe escalation.")
    s.rect(0.85, 2.0, 3.45, 3.45, fill=COLORS["panel"], line=COLORS["line"])
    s.text(1.15, 2.3, 2.85, 0.35, "User chat", size=20, color=COLORS["white"], bold=True)
    s.bullet_list(1.15, 2.92, 2.65, 1.55, [
        "Real-time WebSocket response",
        "Clarifies vague issues",
        "Shows source-backed answers",
        "Creates ticket when needed"
    ], size=13, color=COLORS["offwhite"], bullet_color=COLORS["cyan"])
    s.rect(4.95, 2.0, 3.45, 3.45, fill=COLORS["panel"], line=COLORS["line"])
    s.text(5.25, 2.3, 2.85, 0.35, "Knowledge brain", size=20, color=COLORS["white"], bold=True)
    s.bullet_list(5.25, 2.92, 2.65, 1.55, [
        "Ingests docs and URLs",
        "Cleans noisy web content",
        "Chunks and embeds knowledge",
        "Retrieves via vector search"
    ], size=13, color=COLORS["offwhite"], bullet_color=COLORS["green"])
    s.rect(9.05, 2.0, 3.45, 3.45, fill=COLORS["panel"], line=COLORS["line"])
    s.text(9.35, 2.3, 2.85, 0.35, "Admin control", size=20, color=COLORS["white"], bold=True)
    s.bullet_list(9.35, 2.92, 2.65, 1.55, [
        "Jira ticket oversight",
        "Resolution and escalation metrics",
        "Knowledge source management",
        "Common issue analytics"
    ], size=13, color=COLORS["offwhite"], bullet_color=COLORS["amber"])
    s.text(1.05, 6.15, 11.1, 0.35, "Built in repo: FastAPI, React, ChromaDB, PostgreSQL, RAG pipeline, confidence service, Jira integration, analytics dashboard.", size=13, color=COLORS["muted"], align="c")
    s.footer("Product scope is based on the current Support-Copilot repository.")
    slides.append(s)

    s = SlideBuilder()
    s.title("How Support-Copilot handles every ticket", "It gives every request an immediate action path instead of dropping it into a queue.")
    steps = [
        ("1", "User asks", "Customer or internal user sends issue in chat.", COLORS["blue"]),
        ("2", "Clarify", "AI asks focused follow-ups when details are missing.", COLORS["cyan"]),
        ("3", "Retrieve", "RAG searches trusted docs and prior knowledge chunks.", COLORS["green"]),
        ("4", "Decide", "Confidence gate chooses resolve, clarify, or escalate.", COLORS["amber"]),
        ("5", "Handoff", "Unknown issues become structured Jira tickets.", COLORS["red"]),
    ]
    start_x = 0.65
    for i, (num, title, desc, accent) in enumerate(steps):
        x = start_x + i * 2.53
        s.rect(x, 2.25, 2.15, 2.45, fill=COLORS["panel"], line=COLORS["line"])
        s.rect(x + 0.18, 2.45, 0.48, 0.48, fill=accent)
        s.text(x + 0.18, 2.56, 0.48, 0.18, num, size=12, color=COLORS["white"], bold=True, align="c")
        s.text(x + 0.18, 3.15, 1.75, 0.3, title, size=17, color=COLORS["white"], bold=True)
        s.text(x + 0.18, 3.63, 1.72, 0.72, desc, size=11, color=COLORS["muted"], line_spacing=92000)
        if i < len(steps) - 1:
            s.line(x + 2.16, 3.45, x + 2.5, 3.45, COLORS["cyan"], width=18000)
    s.rect(1.1, 5.6, 11.1, 0.9, fill=COLORS["panel2"], line=COLORS["line"])
    s.text(1.35, 5.88, 10.6, 0.3, "Key judging point: AI does not guess blindly. It either answers with sources, asks for missing facts, or escalates with context.", size=18, color=COLORS["white"], bold=True, align="c")
    s.footer()
    slides.append(s)

    s = SlideBuilder()
    s.title("Before vs after: the daily L2 routine", "Support-Copilot compresses triage, searching, and ticket writing into a live workflow.")
    s.rect(0.85, 2.0, 5.6, 3.85, fill=COLORS["panel"], line=COLORS["line"])
    s.text(1.15, 2.28, 4.7, 0.36, "Today: manual queue", size=23, color=COLORS["white"], bold=True)
    s.bullet_list(1.25, 3.02, 4.65, 1.95, [
        "Ticket waits for first human attention",
        "Agent reads history and asks basic questions",
        "Agent searches docs/runbooks manually",
        "Agent writes summary and Jira fields again",
        "Off-hours issues wait until team is online"
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["red"], line_spacing=102000)
    s.rect(6.9, 2.0, 5.6, 3.85, fill=COLORS["panel2"], line=COLORS["cyan"])
    s.text(7.2, 2.28, 4.7, 0.36, "With Support-Copilot", size=23, color=COLORS["white"], bold=True)
    s.bullet_list(7.3, 3.02, 4.65, 1.95, [
        "Every ticket gets instant 24/7 triage",
        "Known issues resolved from trusted docs",
        "Vague requests get guided clarification",
        "Unknown issues become Jira-ready tickets",
        "Dashboard reveals repeat issues and gaps"
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["green"], line_spacing=102000)
    s.text(1.0, 6.33, 11.2, 0.3, "The result is not replacing L2. It is removing repeatable work so L2 can focus on incidents that genuinely need engineering judgment.", size=13, color=COLORS["muted"], align="c")
    s.footer()
    slides.append(s)

    s = SlideBuilder()
    s.title("Time reduction: benchmark-backed impact", "External benchmark data shows the same pattern: AI reduces waiting, searching, and rewriting time.")
    add_bar(s, 0.95, 2.0, 4.1, "Real-time conversation resolution", "41 min", 1.0, COLORS["slate"])
    add_bar(s, 0.95, 2.85, 4.1, "With AI copilot", "2 min", 0.05, COLORS["green"])
    s.text(6.1, 2.25, 5.8, 0.45, "Freshworks 2025 benchmark: real-time conversations averaged 41 minutes without AI assistance and 2 minutes with AI copilots.", size=16, color=COLORS["offwhite"], line_spacing=93000)
    add_bar(s, 0.95, 4.25, 4.1, "Service ticket resolution", "36 hrs", 1.0, COLORS["slate"])
    add_bar(s, 0.95, 5.10, 4.1, "Extensive AI usage", "32 min", 0.03, COLORS["cyan"])
    s.text(6.1, 4.56, 5.8, 0.45, "Freshworks also reports service tickets moving from 36 hours to 32 minutes for extensive AI users; 2024 data showed up to 38% resolution-time reduction from GenAI features.", size=16, color=COLORS["offwhite"], line_spacing=93000)
    s.footer("Benchmarks are external references; pilot KPIs should validate Support-Copilot on our ticket mix.")
    slides.append(s)

    s = SlideBuilder()
    s.title("Ticket-volume model for a 100-ticket L2 day", "Conservative, judge-friendly assumption: not every ticket is automated, but every ticket is helped.")
    s.rect(0.9, 2.05, 11.6, 0.65, fill=COLORS["panel2"], line=COLORS["line"])
    s.text(1.1, 2.24, 1.55, 0.24, "100 tickets", size=18, color=COLORS["white"], bold=True)
    s.text(2.65, 2.25, 8.9, 0.22, "all receive immediate AI triage instead of waiting in queue", size=13, color=COLORS["muted"])
    segments = [
        (0.90, "45-55", "resolved directly from docs/runbooks", COLORS["green"]),
        (5.95, "20-25", "clarified, guided, or partially solved", COLORS["cyan"]),
        (8.75, "20-30", "escalated with structured Jira context", COLORS["amber"]),
    ]
    for x, value, label, color in segments:
        w = 4.7 if x == 0.9 else 2.45 if x == 5.95 else 3.75
        s.rect(x, 3.35, w, 1.55, fill=COLORS["panel"], line=color)
        s.text(x + 0.22, 3.62, w - 0.44, 0.36, value, size=31, color=color, bold=True, font="Aptos Display")
        s.text(x + 0.25, 4.16, w - 0.5, 0.35, label, size=13, color=COLORS["offwhite"])
    s.rect(0.9, 5.65, 11.6, 0.82, fill=COLORS["ink"], line=COLORS["line"])
    s.text(1.18, 5.88, 10.9, 0.28, "Expected L2 touch reduction: roughly 35-50 manual tickets/day, depending on knowledge-base coverage and confidence threshold.", size=17, color=COLORS["white"], bold=True, align="c")
    s.footer("Model uses conservative planning assumptions informed by Gartner, Freshworks, and our RAG/confidence design.")
    slides.append(s)

    s = SlideBuilder()
    s.title("Capacity and ROI model", "A simple 100-ticket/day team can reclaim hundreds of L2 hours per month.")
    s.metric_card(0.8, 2.0, 2.8, 1.35, "2,200", "tickets/month at 100 per business day", accent=COLORS["blue"])
    s.metric_card(3.95, 2.0, 2.8, 1.35, "990", "manual tickets avoided at 45% direct resolution", accent=COLORS["green"])
    s.metric_card(7.1, 2.0, 2.8, 1.35, "495 hrs", "saved/month at 30 min manual effort each", accent=COLORS["cyan"])
    s.metric_card(10.25, 2.0, 2.25, 1.35, "~3 FTE", "capacity unlocked at 160 hrs/month", accent=COLORS["amber"])
    s.rect(1.0, 4.05, 11.3, 1.3, fill=COLORS["panel"], line=COLORS["line"])
    s.text(1.28, 4.32, 10.75, 0.35, "At $35/hour fully loaded support cost, that is about $17K/month or $208K/year in capacity value.", size=21, color=COLORS["white"], bold=True, align="c")
    s.text(1.28, 4.93, 10.75, 0.25, "The bigger prize: faster customer recovery, cleaner incident data, and fewer repeat questions reaching L2.", size=13, color=COLORS["muted"], align="c")
    s.footer("Cost calculation is adjustable; it is shown to make the impact tangible.")
    slides.append(s)

    s = SlideBuilder()
    s.title("Why this is more than a chatbot", "The strongest pitch is control: Support-Copilot is designed for technical support risk, not generic FAQ answers.")
    rows = [
        ("Grounded RAG", "Answers from approved docs and knowledge chunks, with source context."),
        ("Confidence routing", "High confidence resolves; low confidence clarifies or escalates."),
        ("Jira-native handoff", "Creates summary, severity, module, environment, errors, and reproduction steps."),
        ("Admin observability", "Managers see resolution rate, escalation rate, common issues, and source health."),
        ("Knowledge gap loop", "Repeated escalations reveal exactly which docs/runbooks must be improved next."),
    ]
    y = 1.95
    for idx, (title, desc) in enumerate(rows):
        color = [COLORS["cyan"], COLORS["green"], COLORS["amber"], COLORS["blue"], COLORS["lime"]][idx]
        s.rect(0.9, y, 11.6, 0.72, fill=COLORS["panel"], line=COLORS["line"])
        s.rect(1.1, y + 0.18, 0.36, 0.36, fill=color)
        s.text(1.65, y + 0.17, 2.4, 0.24, title, size=15, color=COLORS["white"], bold=True)
        s.text(4.0, y + 0.17, 7.95, 0.24, desc, size=13, color=COLORS["muted"])
        y += 0.9
    s.footer()
    slides.append(s)

    s = SlideBuilder()
    s.title("Demo storyline for judges", "A crisp three-minute demo can show the entire value chain.")
    s.rect(0.9, 1.95, 3.55, 3.9, fill=COLORS["panel"], line=COLORS["cyan"])
    s.text(1.2, 2.22, 2.9, 0.3, "1. Admin loads knowledge", size=18, color=COLORS["white"], bold=True)
    s.bullet_list(1.2, 2.9, 2.75, 1.6, [
        "Add documentation URL",
        "Show indexed status",
        "Show source count"
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["cyan"])
    s.rect(4.9, 1.95, 3.55, 3.9, fill=COLORS["panel"], line=COLORS["green"])
    s.text(5.2, 2.22, 2.9, 0.3, "2. User asks known issue", size=18, color=COLORS["white"], bold=True)
    s.bullet_list(5.2, 2.9, 2.75, 1.6, [
        "AI streams response",
        "Shows source-backed fix",
        "No L2 agent required"
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["green"])
    s.rect(8.9, 1.95, 3.55, 3.9, fill=COLORS["panel"], line=COLORS["amber"])
    s.text(9.2, 2.22, 2.9, 0.3, "3. Unknown issue escalates", size=18, color=COLORS["white"], bold=True)
    s.bullet_list(9.2, 2.9, 2.75, 1.6, [
        "AI asks clarifying questions",
        "Creates Jira ticket",
        "Admin dashboard updates"
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["amber"])
    s.text(1.0, 6.35, 11.2, 0.25, "Judges see: customer experience, AI reasoning guardrails, operational workflow, and measurable support-team value.", size=13, color=COLORS["muted"], align="c")
    s.footer()
    slides.append(s)

    s = SlideBuilder()
    s.title("Pilot ask and winning KPI targets", "The next step is a focused pilot, not a science project.")
    s.rect(0.85, 2.0, 5.65, 3.75, fill=COLORS["panel"], line=COLORS["line"])
    s.text(1.15, 2.3, 4.7, 0.32, "2-week pilot", size=22, color=COLORS["white"], bold=True)
    s.bullet_list(1.2, 2.95, 4.7, 1.9, [
        "Index top product docs and top 20 resolved issue types",
        "Route a sample L2 queue through Support-Copilot",
        "Compare manual vs AI-assisted response and resolution time",
        "Review escalated tickets for completeness and quality"
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["cyan"])
    s.rect(6.9, 2.0, 5.55, 3.75, fill=COLORS["panel2"], line=COLORS["green"])
    s.text(7.2, 2.3, 4.7, 0.32, "Target outcomes", size=22, color=COLORS["white"], bold=True)
    s.bullet_list(7.25, 2.95, 4.55, 1.9, [
        "First AI response under 60 seconds, 24/7",
        "30%+ manual L2 volume reduction in pilot queue",
        "45%+ direct resolution for documented repeat issues",
        "90%+ escalations include complete Jira handoff fields"
    ], size=14, color=COLORS["offwhite"], bullet_color=COLORS["green"])
    s.text(1.0, 6.35, 11.2, 0.3, "Winning close: Support-Copilot gives every ticket immediate attention and gives every L2 engineer more time for the work only humans can do.", size=15, color=COLORS["white"], bold=True, align="c")
    s.footer()
    slides.append(s)

    s = SlideBuilder(bg="F8FAFC")
    s.text(0.7, 0.55, 11.8, 0.6, "Benchmark Sources & Assumptions", size=32, color=COLORS["navy"], bold=True, font="Aptos Display")
    s.rect(0.8, 1.55, 11.75, 4.55, fill="FFFFFF", line="CBD5E1")
    source_lines = [
        "Gartner, Mar 5 2025: Agentic AI predicted to autonomously resolve 80% of common customer service issues by 2029 and reduce operational costs by 30%.",
        "McKinsey, The economic potential of generative AI: customer-care productivity value estimated at 30-45% of current function costs.",
        "Freshworks 2024 benchmark: GenAI summarizer/rephraser can reduce resolution time by up to 38%; knowledge bases can halve resolution times.",
        "Freshworks 2025 benchmark article: AI copilots reported 41 min -> 2 min for real-time conversations and 36 hrs -> 32 min for service tickets in high-AI cohorts.",
        "Salesforce State of Service 2024: 77% of agents report workload increased; 65% report more complex cases; agents spend 39% of time servicing customers; 76% of service orgs anticipate higher case volume.",
    ]
    s.bullet_list(1.15, 1.9, 10.9, 2.15, source_lines, size=11, color=COLORS["ink"], bullet_color=COLORS["blue"], line_spacing=94000)
    s.line(1.1, 4.57, 12.0, 4.57, "CBD5E1", width=9000)
    s.text(1.15, 4.8, 10.9, 0.6, "Planning model notes: The 100-ticket/day example is a conservative pitch model, not a production guarantee. Actual resolution rate depends on documentation coverage, issue mix, confidence thresholds, and integration quality.", size=12, color=COLORS["ink"], line_spacing=95000)
    s.text(1.15, 5.55, 10.9, 0.25, "Positioning line: automate known issues, accelerate unclear issues, and escalate unknown issues with better context.", size=13, color=COLORS["blue"], bold=True)
    s.text(0.8, 6.68, 11.6, 0.28, "Use these citations in the verbal pitch when judges challenge the numbers.", size=11, color=COLORS["slate"], align="c")
    slides.append(s)

    return slides


def content_types(num_slides: int) -> str:
    overrides = "\n".join(
        f'<Override PartName="/ppt/slides/slide{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'
        for i in range(1, num_slides + 1)
    )
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
      <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
      <Default Extension="xml" ContentType="application/xml"/>
      <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
      <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
      <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
      <Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
      <Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>
      <Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>
      {overrides}
    </Types>
    """


def root_rels() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
      <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
    </Relationships>
    """


def app_xml(num_slides: int) -> str:
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
                xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
      <Application>Codex</Application>
      <PresentationFormat>On-screen Show (16:9)</PresentationFormat>
      <Slides>{num_slides}</Slides>
      <Notes>0</Notes>
      <HiddenSlides>0</HiddenSlides>
      <ScaleCrop>false</ScaleCrop>
      <Company>SemiColon2026</Company>
      <LinksUpToDate>false</LinksUpToDate>
      <SharedDoc>false</SharedDoc>
      <HyperlinksChanged>false</HyperlinksChanged>
      <AppVersion>16.0000</AppVersion>
    </Properties>
    """


def core_xml() -> str:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
                       xmlns:dc="http://purl.org/dc/elements/1.1/"
                       xmlns:dcterms="http://purl.org/dc/terms/"
                       xmlns:dcmitype="http://purl.org/dc/dcmitype/"
                       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
      <dc:title>Support-Copilot Pitch Deck</dc:title>
      <dc:subject>AI-powered L2 support copilot stakeholder pitch</dc:subject>
      <dc:creator>Codex</dc:creator>
      <cp:lastModifiedBy>Codex</cp:lastModifiedBy>
      <dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>
      <dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified>
    </cp:coreProperties>
    """


def presentation_xml(num_slides: int) -> str:
    ids = "\n".join(f'<p:sldId id="{255 + i}" r:id="rId{i + 1}"/>' for i in range(1, num_slides + 1))
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
                    xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
                    xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
      <p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>
      <p:sldIdLst>{ids}</p:sldIdLst>
      <p:sldSz cx="{SLIDE_W}" cy="{SLIDE_H}" type="wide"/>
      <p:notesSz cx="6858000" cy="9144000"/>
      <p:defaultTextStyle>
        <a:defPPr><a:defRPr lang="en-US"/></a:defPPr>
      </p:defaultTextStyle>
    </p:presentation>
    """


def presentation_rels(num_slides: int) -> str:
    rels = ['<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>']
    for i in range(1, num_slides + 1):
        rels.append(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide{i}.xml"/>')
    rels.append(f'<Relationship Id="rId{num_slides + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>')
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      {''.join(rels)}
    </Relationships>
    """


def slide_rels() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
    </Relationships>
    """


def slide_master_xml() -> str:
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
                 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
                 xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
      <p:cSld>
        <p:spTree>
          <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
          <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{SLIDE_W}" cy="{SLIDE_H}"/><a:chOff x="0" y="0"/><a:chExt cx="{SLIDE_W}" cy="{SLIDE_H}"/></a:xfrm></p:grpSpPr>
        </p:spTree>
      </p:cSld>
      <p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>
      <p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>
      <p:txStyles>
        <p:titleStyle><a:lvl1pPr><a:defRPr sz="4400"/></a:lvl1pPr></p:titleStyle>
        <p:bodyStyle><a:lvl1pPr><a:defRPr sz="1800"/></a:lvl1pPr></p:bodyStyle>
        <p:otherStyle><a:lvl1pPr><a:defRPr sz="1800"/></a:lvl1pPr></p:otherStyle>
      </p:txStyles>
    </p:sldMaster>
    """


def slide_master_rels() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>
    </Relationships>
    """


def slide_layout_xml() -> str:
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
                 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
                 xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
                 type="blank" preserve="1">
      <p:cSld name="Blank">
        <p:spTree>
          <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
          <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{SLIDE_W}" cy="{SLIDE_H}"/><a:chOff x="0" y="0"/><a:chExt cx="{SLIDE_W}" cy="{SLIDE_H}"/></a:xfrm></p:grpSpPr>
        </p:spTree>
      </p:cSld>
      <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
    </p:sldLayout>
    """


def slide_layout_rels() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>
    </Relationships>
    """


def theme_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Support Copilot Theme">
      <a:themeElements>
        <a:clrScheme name="Support Copilot">
          <a:dk1><a:srgbClr val="08111F"/></a:dk1>
          <a:lt1><a:srgbClr val="FFFFFF"/></a:lt1>
          <a:dk2><a:srgbClr val="132238"/></a:dk2>
          <a:lt2><a:srgbClr val="F8FAFC"/></a:lt2>
          <a:accent1><a:srgbClr val="2563EB"/></a:accent1>
          <a:accent2><a:srgbClr val="06B6D4"/></a:accent2>
          <a:accent3><a:srgbClr val="16A34A"/></a:accent3>
          <a:accent4><a:srgbClr val="F59E0B"/></a:accent4>
          <a:accent5><a:srgbClr val="DC2626"/></a:accent5>
          <a:accent6><a:srgbClr val="64748B"/></a:accent6>
          <a:hlink><a:srgbClr val="2563EB"/></a:hlink>
          <a:folHlink><a:srgbClr val="7C3AED"/></a:folHlink>
        </a:clrScheme>
        <a:fontScheme name="Aptos">
          <a:majorFont><a:latin typeface="Aptos Display"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>
          <a:minorFont><a:latin typeface="Aptos"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont>
        </a:fontScheme>
        <a:fmtScheme name="Support">
          <a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"/></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"/></a:gs></a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>
          <a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="25400"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="38100"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst>
          <a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>
          <a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst>
        </a:fmtScheme>
      </a:themeElements>
      <a:objectDefaults/>
      <a:extraClrSchemeLst/>
    </a:theme>
    """


def write_deck() -> None:
    slides = build_slides()
    with zipfile.ZipFile(PPTX_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types(len(slides)))
        zf.writestr("_rels/.rels", root_rels())
        zf.writestr("docProps/app.xml", app_xml(len(slides)))
        zf.writestr("docProps/core.xml", core_xml())
        zf.writestr("ppt/presentation.xml", presentation_xml(len(slides)))
        zf.writestr("ppt/_rels/presentation.xml.rels", presentation_rels(len(slides)))
        zf.writestr("ppt/theme/theme1.xml", theme_xml())
        zf.writestr("ppt/slideMasters/slideMaster1.xml", slide_master_xml())
        zf.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels", slide_master_rels())
        zf.writestr("ppt/slideLayouts/slideLayout1.xml", slide_layout_xml())
        zf.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", slide_layout_rels())
        for idx, slide in enumerate(slides, 1):
            zf.writestr(f"ppt/slides/slide{idx}.xml", slide.xml())
            zf.writestr(f"ppt/slides/_rels/slide{idx}.xml.rels", slide_rels())
    print(PPTX_PATH)


if __name__ == "__main__":
    write_deck()
